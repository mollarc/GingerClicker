<?php
session_start();
include 'db_connection.php'; 

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $score = $_POST['score'];
    // Add other fields as needed

    $query = "UPDATE player_game_info SET player_score='$score' WHERE user_id=(SELECT uid FROM player_login WHERE player_name='$username')";
    mysqli_query($conn, $query);

    echo "Game data saved successfully";
} else {
    echo "User not logged in";
}
?>
