<?php
include 'db_connection.php'; // Include your database connection script

$query = "SELECT player_name, player_score FROM leaderboard ORDER BY player_score DESC";
$result = mysqli_query($conn, $query);

$leaderboard = array();
while ($row = mysqli_fetch_assoc($result)) {
    $leaderboard[] = $row;
}

echo json_encode($leaderboard);
?>
