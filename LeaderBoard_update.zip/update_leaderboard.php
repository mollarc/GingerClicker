<?php
include 'db_connection.php'; // Include your database connection script

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $score = $_POST['score'];

    // Check if the user already exists in the leaderboard
    $query = "SELECT * FROM leaderboard WHERE player_name='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Update existing record
        $query = "UPDATE leaderboard SET player_score='$score' WHERE player_name='$username'";
    } else {
        // Insert new record
        $query = "INSERT INTO leaderboard (player_name, player_score) VALUES ('$username', '$score')";
    }

    mysqli_query($conn, $query);
    echo "Leaderboard updated successfully";
}
?>
