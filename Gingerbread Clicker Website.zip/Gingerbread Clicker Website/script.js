// Get the modal
var modal = document.getElementById("loginModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// Get the "Continue as Guest" button
var guestButton = document.getElementById("guestButton");

// When the page loads, open the modal
window.onload = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks on the "Continue as Guest" button, close the modal
guestButton.onclick = function() {
    modal.style.display = "none";
}
document.addEventListener("DOMContentLoaded", () => {
    const loginModal = document.getElementById("loginModal");
    const closeModal = document.querySelector(".close");

    // Check if the modal has already been shown
    if (!localStorage.getItem("modalShown")) {
        loginModal.style.display = "block"; // Show the modal
        localStorage.setItem("modalShown", "true"); // Mark the modal as shown
    }

    // Close the modal when the close button is clicked
    closeModal.addEventListener("click", () => {
        loginModal.style.display = "none";
    });

    // Close the modal when clicking outside of it
    window.addEventListener("click", (event) => {
        if (event.target === loginModal) {
            loginModal.style.display = "none";
        }
    });
});